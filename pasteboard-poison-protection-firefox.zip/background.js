/**
 * Pasteboard Poison Protection - Background Script
 * Manages clipboard hash storage and coordinates threat detection
 */

class ClipboardProtectionBackground {
    constructor() {
        this.clipboardHashes = new Map();
        this.statistics = {
            copiesMonitored: 0,
            threatsDetected: 0,
            lastActivity: null
        };
        this.settings = {
            sensitivityThreshold: 90,
            hashExpiryMinutes: 5,
            protectionEnabled: true
        };

        this.init();
    }

    init() {
        console.log('Pasteboard Poison Protection - Background script initialized');

        // Load settings from storage
        this.loadSettings();

        // Listen for messages from content scripts
        browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
            this.handleMessage(request, sender, sendResponse);
            return true; // Will respond asynchronously
        });

        // Clean up expired hashes every minute
        setInterval(() => this.cleanupExpiredHashes(), 60000);

        // Initialize browser action badge
        this.updateBadge();
    }

    async loadSettings() {
        try {
            const result = await browser.storage.local.get(['pasteboardSettings', 'pasteboardStats']);

            if (result.pasteboardSettings) {
                this.settings = { ...this.settings, ...result.pasteboardSettings };
            }

            if (result.pasteboardStats) {
                this.statistics = { ...this.statistics, ...result.pasteboardStats };
            }
        } catch (error) {
            console.error('Error loading settings:', error);
        }
    }

    async saveSettings() {
        try {
            await browser.storage.local.set({
                pasteboardSettings: this.settings,
                pasteboardStats: this.statistics
            });
        } catch (error) {
            console.error('Error saving settings:', error);
        }
    }

    async handleMessage(request, sender, sendResponse) {
        try {
            switch (request.action) {
                case 'storeCopyHash':
                    await this.storeCopyHash(request.hash, request.content, request.timestamp);
                    sendResponse({ success: true });
                    break;

                case 'checkPasteHash':
                    const threat = await this.checkPasteHash(request.hash, request.content, request.timestamp);
                    sendResponse({ threat, settings: this.settings });
                    break;

                case 'getSettings':
                    sendResponse({ settings: this.settings, statistics: this.statistics });
                    break;

                case 'updateSettings':
                    this.settings = { ...this.settings, ...request.settings };
                    await this.saveSettings();
                    this.updateBadge();
                    sendResponse({ success: true });
                    break;

                case 'getStatistics':
                    sendResponse({ statistics: this.statistics });
                    break;

                case 'clearClipboardHistory':
                    this.clipboardHashes.clear();
                    sendResponse({ success: true });
                    break;

                default:
                    sendResponse({ error: 'Unknown action' });
            }
        } catch (error) {
            console.error('Background script error:', error);
            sendResponse({ error: error.message });
        }
    }

    async storeCopyHash(hash, contentLength, timestamp) {
        if (!this.settings.protectionEnabled) return;

        // Store hash with metadata
        this.clipboardHashes.set(hash, {
            timestamp: timestamp,
            contentLength: contentLength,
            expires: timestamp + (this.settings.hashExpiryMinutes * 60 * 1000)
        });

        // Update statistics
        this.statistics.copiesMonitored++;
        this.statistics.lastActivity = new Date().toISOString();

        await this.saveSettings();
        this.updateBadge();

        console.log(`Stored clipboard hash: ${hash.substring(0, 8)}... (length: ${contentLength})`);
    }

    async checkPasteHash(hash, content, timestamp) {
        if (!this.settings.protectionEnabled) return null;

        // Check if we have a matching copy hash
        let matchingHash = null;
        let bestMatch = null;
        let similarity = 0;

        for (const [storedHash, metadata] of this.clipboardHashes.entries()) {
            if (storedHash === hash) {
                // Exact match - no threat
                matchingHash = storedHash;
                similarity = 100;
                break;
            } else {
                // Check if this might be a modified version
                // We can't compare content directly for privacy, but we can note the difference
                if (Math.abs(metadata.contentLength - content.length) < content.length * 0.1) {
                    // Similar length - potential modified content
                    bestMatch = { hash: storedHash, metadata };
                }
            }
        }

        if (matchingHash) {
            // Exact match found - safe paste
            return null;
        } else if (bestMatch && this.clipboardHashes.size > 0) {
            // Potential threat - content may have been modified
            this.statistics.threatsDetected++;
            this.statistics.lastActivity = new Date().toISOString();
            await this.saveSettings();
            this.updateBadge();

            // Create threat notification
            await this.showThreatNotification(content);

            return {
                type: 'clipboard_hijack',
                severity: 'high',
                originalLength: bestMatch.metadata.contentLength,
                modifiedLength: content.length,
                timestamp: timestamp,
                message: 'Clipboard content may have been modified by malware!'
            };
        }

        return null;
    }

    async showThreatNotification(content) {
        try {
            const contentPreview = content.length > 50 ? content.substring(0, 50) + '...' : content;

            await browser.notifications.create({
                type: 'basic',
                iconUrl: 'icon48.png',
                title: '🚨 Clipboard Hijack Detected!',
                message: `Pasted content differs from copied content: "${contentPreview}"`,
                priority: 2
            });
        } catch (error) {
            console.error('Error showing notification:', error);
        }
    }

    cleanupExpiredHashes() {
        const now = Date.now();
        let cleaned = 0;

        for (const [hash, metadata] of this.clipboardHashes.entries()) {
            if (now > metadata.expires) {
                this.clipboardHashes.delete(hash);
                cleaned++;
            }
        }

        if (cleaned > 0) {
            console.log(`Cleaned up ${cleaned} expired clipboard hashes`);
            this.updateBadge();
        }
    }

    updateBadge() {
        if (!this.settings.protectionEnabled) {
            browser.browserAction.setBadgeText({ text: 'OFF' });
            browser.browserAction.setBadgeBackgroundColor({ color: '#666666' });
        } else if (this.statistics.threatsDetected > 0) {
            browser.browserAction.setBadgeText({ text: this.statistics.threatsDetected.toString() });
            browser.browserAction.setBadgeBackgroundColor({ color: '#F44336' });
        } else {
            browser.browserAction.setBadgeText({ text: '' });
            browser.browserAction.setBadgeBackgroundColor({ color: '#4CAF50' });
        }
    }
}

// Initialize background script
new ClipboardProtectionBackground();
