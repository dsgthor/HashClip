/**
 * Pasteboard Poison Protection - Popup Script
 * Handles popup UI interactions and communication with background script
 */

class PopupController {
    constructor() {
        this.settings = {};
        this.statistics = {};
        this.activityLog = [];

        this.init();
    }

    async init() {
        console.log('Popup initialized');

        // Load initial data
        await this.loadData();

        // Setup event listeners
        this.setupEventListeners();

        // Update UI
        this.updateUI();

        // Setup periodic updates
        this.startPeriodicUpdates();
    }

    async loadData() {
        try {
            // Get settings and statistics from background script
            const response = await browser.runtime.sendMessage({
                action: 'getSettings'
            });

            if (response && response.settings) {
                this.settings = response.settings;
                this.statistics = response.statistics || {};
            }

        } catch (error) {
            console.error('Error loading data:', error);
            // Use default settings if background script not available
            this.settings = {
                protectionEnabled: true,
                sensitivityThreshold: 90,
                hashExpiryMinutes: 5
            };
            this.statistics = {
                copiesMonitored: 0,
                threatsDetected: 0,
                lastActivity: null
            };
        }
    }

    setupEventListeners() {
        // Protection toggle
        const protectionToggle = document.getElementById('protectionToggle');
        protectionToggle.addEventListener('change', (e) => {
            this.toggleProtection(e.target.checked);
        });

        // Sensitivity slider
        const sensitivitySlider = document.getElementById('sensitivitySlider');
        const sensitivityValue = document.getElementById('sensitivityValue');

        sensitivitySlider.addEventListener('input', (e) => {
            const value = e.target.value;
            sensitivityValue.textContent = value + '%';
            this.updateSetting('sensitivityThreshold', parseInt(value));
        });

        // Hash expiry
        const hashExpiry = document.getElementById('hashExpiry');
        hashExpiry.addEventListener('change', (e) => {
            this.updateSetting('hashExpiryMinutes', parseInt(e.target.value));
        });

        // Action buttons
        document.getElementById('clearHistory').addEventListener('click', () => {
            this.clearHistory();
        });

        document.getElementById('testProtection').addEventListener('click', () => {
            this.testProtection();
        });
    }

    updateUI() {
        // Update status indicator
        this.updateStatusIndicator();

        // Update protection toggle
        const protectionToggle = document.getElementById('protectionToggle');
        protectionToggle.checked = this.settings.protectionEnabled;

        // Update statistics
        document.getElementById('copiesMonitored').textContent = this.statistics.copiesMonitored || 0;
        document.getElementById('threatsDetected').textContent = this.statistics.threatsDetected || 0;
        document.getElementById('activeHashes').textContent = '0'; // Will be updated separately

        // Update settings
        const sensitivitySlider = document.getElementById('sensitivitySlider');
        const sensitivityValue = document.getElementById('sensitivityValue');
        const hashExpiry = document.getElementById('hashExpiry');

        sensitivitySlider.value = this.settings.sensitivityThreshold || 90;
        sensitivityValue.textContent = (this.settings.sensitivityThreshold || 90) + '%';
        hashExpiry.value = this.settings.hashExpiryMinutes || 5;

        // Update activity log
        this.updateActivityLog();
    }

    updateStatusIndicator() {
        const statusDot = document.getElementById('statusDot');
        const statusText = document.getElementById('statusText');

        if (this.settings.protectionEnabled) {
            statusDot.className = 'status-dot active';
            statusText.textContent = 'Protected';
        } else {
            statusDot.className = 'status-dot inactive';
            statusText.textContent = 'Disabled';
        }
    }

    updateActivityLog() {
        const activityLog = document.getElementById('activityLog');

        if (this.activityLog.length === 0) {
            activityLog.innerHTML = `
                <div class="activity-item">
                    <span class="activity-time">--:--</span>
                    <span class="activity-message">No recent activity</span>
                </div>
            `;
            return;
        }

        const html = this.activityLog
            .slice(-5) // Show last 5 activities
            .reverse()
            .map(activity => {
                const time = new Date(activity.timestamp).toLocaleTimeString('en-US', {
                    hour12: false,
                    hour: '2-digit',
                    minute: '2-digit'
                });

                const itemClass = activity.type === 'threat' ? 'threat' : 
                                 activity.type === 'safe' ? 'safe' : '';

                return `
                    <div class="activity-item ${itemClass}">
                        <span class="activity-time">${time}</span>
                        <span class="activity-message">${activity.message}</span>
                    </div>
                `;
            })
            .join('');

        activityLog.innerHTML = html;
    }

    async toggleProtection(enabled) {
        try {
            await browser.runtime.sendMessage({
                action: 'updateSettings',
                settings: { protectionEnabled: enabled }
            });

            this.settings.protectionEnabled = enabled;
            this.updateStatusIndicator();

            this.showToast(
                enabled ? 'success' : 'warning',
                enabled ? 'Protection Enabled' : 'Protection Disabled'
            );

            this.addActivity(
                enabled ? 'info' : 'warning',
                enabled ? 'Protection enabled' : 'Protection disabled'
            );

        } catch (error) {
            console.error('Error toggling protection:', error);
            this.showToast('error', 'Failed to update protection status');
        }
    }

    async updateSetting(key, value) {
        try {
            const settings = { [key]: value };

            await browser.runtime.sendMessage({
                action: 'updateSettings',
                settings: settings
            });

            this.settings[key] = value;

            this.addActivity('info', `Setting updated: ${key} = ${value}`);

        } catch (error) {
            console.error('Error updating setting:', error);
            this.showToast('error', 'Failed to update setting');
        }
    }

    async clearHistory() {
        try {
            await browser.runtime.sendMessage({
                action: 'clearClipboardHistory'
            });

            this.showToast('success', 'Clipboard history cleared');
            this.addActivity('info', 'Clipboard history cleared');

            // Reset active hashes counter
            document.getElementById('activeHashes').textContent = '0';

        } catch (error) {
            console.error('Error clearing history:', error);
            this.showToast('error', 'Failed to clear history');
        }
    }

    testProtection() {
        // Create a test scenario
        this.addActivity('info', 'Protection test initiated');

        // Simulate a test notification
        setTimeout(() => {
            this.addActivity('safe', 'Test completed - Protection working');
            this.showToast('success', 'Protection test completed successfully');
        }, 1000);
    }

    addActivity(type, message) {
        const activity = {
            type: type,
            message: message,
            timestamp: new Date().toISOString()
        };

        this.activityLog.push(activity);

        // Keep only last 10 activities
        if (this.activityLog.length > 10) {
            this.activityLog = this.activityLog.slice(-10);
        }

        this.updateActivityLog();
    }

    showToast(type, message) {
        // Remove existing toasts
        const existingToasts = document.querySelectorAll('.toast');
        existingToasts.forEach(toast => toast.remove());

        // Create new toast
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.textContent = message;

        document.body.appendChild(toast);

        // Remove toast after 3 seconds
        setTimeout(() => {
            if (toast.parentElement) {
                toast.remove();
            }
        }, 3000);
    }

    startPeriodicUpdates() {
        // Update statistics every 5 seconds
        setInterval(async () => {
            try {
                const response = await browser.runtime.sendMessage({
                    action: 'getStatistics'
                });

                if (response && response.statistics) {
                    this.statistics = response.statistics;

                    // Update only statistics elements
                    document.getElementById('copiesMonitored').textContent = this.statistics.copiesMonitored || 0;
                    document.getElementById('threatsDetected').textContent = this.statistics.threatsDetected || 0;
                }

            } catch (error) {
                // Background script may not be available
                console.log('Unable to update statistics:', error.message);
            }
        }, 5000);
    }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PopupController();
});

// Handle popup close
window.addEventListener('beforeunload', () => {
    console.log('Popup closing');
});
