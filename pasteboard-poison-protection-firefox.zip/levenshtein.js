/**
 * Levenshtein Distance Implementation
 * Efficient algorithm for calculating string similarity
 */

/**
 * Calculate Levenshtein distance between two strings
 * @param {string} str1 - First string
 * @param {string} str2 - Second string
 * @returns {number} - Edit distance between strings
 */
function levenshteinDistance(str1, str2) {
    // Handle edge cases
    if (str1 === str2) return 0;
    if (str1.length === 0) return str2.length;
    if (str2.length === 0) return str1.length;

    // Create matrix for dynamic programming
    const matrix = Array(str2.length + 1)
        .fill(null)
        .map(() => Array(str1.length + 1).fill(0));

    // Initialize first row and column
    for (let i = 0; i <= str1.length; i++) {
        matrix[0][i] = i;
    }
    for (let j = 0; j <= str2.length; j++) {
        matrix[j][0] = j;
    }

    // Fill the matrix
    for (let j = 1; j <= str2.length; j++) {
        for (let i = 1; i <= str1.length; i++) {
            const substitutionCost = str1[i - 1] === str2[j - 1] ? 0 : 1;

            matrix[j][i] = Math.min(
                matrix[j][i - 1] + 1,           // insertion
                matrix[j - 1][i] + 1,           // deletion
                matrix[j - 1][i - 1] + substitutionCost  // substitution
            );
        }
    }

    return matrix[str2.length][str1.length];
}

/**
 * Calculate similarity percentage between two strings
 * @param {string} str1 - First string
 * @param {string} str2 - Second string
 * @returns {number} - Similarity percentage (0-100)
 */
function calculateSimilarity(str1, str2) {
    if (str1 === str2) return 100;
    if (str1.length === 0 && str2.length === 0) return 100;
    if (str1.length === 0 || str2.length === 0) return 0;

    const distance = levenshteinDistance(str1, str2);
    const maxLength = Math.max(str1.length, str2.length);
    const similarity = ((maxLength - distance) / maxLength) * 100;

    return Math.max(0, similarity);
}

/**
 * Optimized Levenshtein distance for large strings
 * Uses single vector instead of full matrix for memory efficiency
 * @param {string} str1 - First string
 * @param {string} str2 - Second string
 * @returns {number} - Edit distance between strings
 */
function optimizedLevenshteinDistance(str1, str2) {
    // Handle edge cases
    if (str1 === str2) return 0;
    if (str1.length === 0) return str2.length;
    if (str2.length === 0) return str1.length;

    // Ensure str1 is the shorter string for memory optimization
    if (str1.length > str2.length) {
        [str1, str2] = [str2, str1];
    }

    // Remove common prefixes and suffixes
    let start = 0;
    while (start < str1.length && str1[start] === str2[start]) {
        start++;
    }

    let end1 = str1.length - 1;
    let end2 = str2.length - 1;
    while (end1 >= start && end2 >= start && str1[end1] === str2[end2]) {
        end1--;
        end2--;
    }

    // Extract the relevant substrings
    const substr1 = str1.substring(start, end1 + 1);
    const substr2 = str2.substring(start, end2 + 1);

    if (substr1.length === 0) return substr2.length;
    if (substr2.length === 0) return substr1.length;

    // Use single vector for space optimization
    let previousRow = Array(substr1.length + 1).fill(0);
    let currentRow = Array(substr1.length + 1).fill(0);

    // Initialize first row
    for (let i = 0; i <= substr1.length; i++) {
        previousRow[i] = i;
    }

    // Calculate distance
    for (let j = 1; j <= substr2.length; j++) {
        currentRow[0] = j;

        for (let i = 1; i <= substr1.length; i++) {
            const substitutionCost = substr1[i - 1] === substr2[j - 1] ? 0 : 1;

            currentRow[i] = Math.min(
                currentRow[i - 1] + 1,              // insertion
                previousRow[i] + 1,                 // deletion
                previousRow[i - 1] + substitutionCost    // substitution
            );
        }

        // Swap rows
        [previousRow, currentRow] = [currentRow, previousRow];
    }

    return previousRow[substr1.length];
}

/**
 * Check if two strings are similar enough based on threshold
 * @param {string} str1 - First string
 * @param {string} str2 - Second string
 * @param {number} threshold - Similarity threshold (0-100)
 * @returns {boolean} - True if strings are similar enough
 */
function isSimilar(str1, str2, threshold = 90) {
    const similarity = calculateSimilarity(str1, str2);
    return similarity >= threshold;
}

/**
 * Detect if clipboard content might have been hijacked
 * @param {string} original - Original copied content
 * @param {string} pasted - Pasted content
 * @param {number} threshold - Similarity threshold (default 90%)
 * @returns {Object} - Detection result with similarity score and threat assessment
 */
function detectClipboardHijack(original, pasted, threshold = 90) {
    const similarity = calculateSimilarity(original, pasted);
    const isHijacked = similarity < threshold && similarity > 0;

    return {
        similarity: Math.round(similarity * 100) / 100,
        isHijacked: isHijacked,
        isExactMatch: similarity === 100,
        isCompletelyDifferent: similarity === 0,
        threatLevel: similarity < 50 ? 'high' : similarity < threshold ? 'medium' : 'low',
        message: isHijacked ? 
            `Content similarity is ${similarity.toFixed(1)}% - possible clipboard hijacking detected!` :
            similarity === 100 ? 'Content matches exactly - safe' : 'Content appears safe'
    };
}

// Export functions for use in other scripts
if (typeof module !== 'undefined' && module.exports) {
    // Node.js environment
    module.exports = {
        levenshteinDistance,
        optimizedLevenshteinDistance,
        calculateSimilarity,
        isSimilar,
        detectClipboardHijack
    };
} else {
    // Browser environment - make functions globally available
    window.LevenshteinUtils = {
        levenshteinDistance,
        optimizedLevenshteinDistance,
        calculateSimilarity,
        isSimilar,
        detectClipboardHijack
    };
}
