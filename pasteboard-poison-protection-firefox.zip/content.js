/**
 * Pasteboard Poison Protection - Content Script
 * Monitors copy/paste events and detects clipboard hijacking
 */

class ClipboardMonitor {
    constructor() {
        this.lastCopiedContent = '';
        this.lastCopiedHash = '';
        this.lastCopyTimestamp = 0;
        this.isInitialized = false;

        this.init();
    }

    async init() {
        console.log('Pasteboard Poison Protection - Content script loaded on:', window.location.hostname);

        // Wait for page to be fully loaded
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setupMonitoring());
        } else {
            this.setupMonitoring();
        }
    }

    setupMonitoring() {
        // Listen for copy events
        document.addEventListener('copy', (event) => this.handleCopyEvent(event), true);

        // Listen for paste events
        document.addEventListener('paste', (event) => this.handlePasteEvent(event), true);

        // Also listen for cut events (treated similar to copy)
        document.addEventListener('cut', (event) => this.handleCopyEvent(event), true);

        this.isInitialized = true;
        console.log('✅ Clipboard monitoring active on', window.location.hostname);
    }

    async handleCopyEvent(event) {
        try {
            // Get the copied content
            let copiedContent = '';

            if (event.clipboardData && event.clipboardData.getData) {
                // Get text from clipboard data
                copiedContent = event.clipboardData.getData('text/plain') || '';
            }

            // If clipboard data not available, try to get selected text
            if (!copiedContent) {
                const selection = window.getSelection();
                if (selection && selection.toString()) {
                    copiedContent = selection.toString();
                }
            }

            // Skip if no content or content is too short
            if (!copiedContent || copiedContent.length < 5) {
                return;
            }

            // Generate hash of the copied content
            const hash = await this.generateHash(copiedContent);

            // Store copy information
            this.lastCopiedContent = copiedContent;
            this.lastCopiedHash = hash;
            this.lastCopyTimestamp = Date.now();

            // Send to background script for storage
            try {
                await browser.runtime.sendMessage({
                    action: 'storeCopyHash',
                    hash: hash,
                    content: copiedContent.length, // Only send length for privacy
                    timestamp: this.lastCopyTimestamp
                });

                console.log(`📋 Copy detected: "${this.truncateContent(copiedContent)}" (${copiedContent.length} chars)`);

                // Show subtle visual feedback
                this.showCopyFeedback();

            } catch (error) {
                console.error('Error communicating with background script:', error);
            }

        } catch (error) {
            console.error('Error handling copy event:', error);
        }
    }

    async handlePasteEvent(event) {
        try {
            // Get pasted content
            let pastedContent = '';

            if (event.clipboardData && event.clipboardData.getData) {
                pastedContent = event.clipboardData.getData('text/plain') || '';
            }

            // Skip if no content
            if (!pastedContent || pastedContent.length < 5) {
                return;
            }

            // Wait a bit to ensure paste is processed
            setTimeout(async () => {
                await this.checkPastedContent(pastedContent);
            }, 100);

        } catch (error) {
            console.error('Error handling paste event:', error);
        }
    }

    async checkPastedContent(pastedContent) {
        try {
            // Generate hash of pasted content
            const pastedHash = await this.generateHash(pastedContent);

            console.log(`📥 Paste detected: "${this.truncateContent(pastedContent)}" (${pastedContent.length} chars)`);

            // Check with background script for threats
            const response = await browser.runtime.sendMessage({
                action: 'checkPasteHash',
                hash: pastedHash,
                content: pastedContent,
                timestamp: Date.now()
            });

            if (response && response.threat) {
                await this.handleThreatDetected(response.threat, pastedContent);
            } else {
                // Check locally as well for immediate comparison
                await this.performLocalThreatCheck(pastedContent, pastedHash);
            }

        } catch (error) {
            console.error('Error checking pasted content:', error);
        }
    }

    async performLocalThreatCheck(pastedContent, pastedHash) {
        // Only check if we have recent copy data
        const timeSinceLastCopy = Date.now() - this.lastCopyTimestamp;

        if (timeSinceLastCopy > 300000) { // 5 minutes
            return; // Too old to be relevant
        }

        if (this.lastCopiedHash && this.lastCopiedHash !== pastedHash) {
            // Hashes don't match - check similarity
            if (this.lastCopiedContent && typeof window.LevenshteinUtils !== 'undefined') {
                const result = window.LevenshteinUtils.detectClipboardHijack(
                    this.lastCopiedContent, 
                    pastedContent, 
                    90
                );

                if (result.isHijacked) {
                    await this.handleThreatDetected({
                        type: 'clipboard_hijack',
                        severity: result.threatLevel,
                        similarity: result.similarity,
                        message: result.message,
                        timestamp: Date.now()
                    }, pastedContent);
                }
            }
        }
    }

    async handleThreatDetected(threat, pastedContent) {
        console.error('🚨 CLIPBOARD HIJACK DETECTED!', threat);

        // Show immediate visual warning
        this.showThreatWarning(threat, pastedContent);

        // Try to clear the potentially malicious content
        // (Note: This is limited by browser security policies)
        this.attemptClipboardClear();
    }

    showThreatWarning(threat, content) {
        // Create warning overlay
        const warning = document.createElement('div');
        warning.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #f44336;
            color: white;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            z-index: 10000;
            max-width: 400px;
            font-family: Arial, sans-serif;
            font-size: 14px;
            line-height: 1.4;
        `;

        const contentPreview = this.truncateContent(content, 30);

        warning.innerHTML = `
            <div style="font-weight: bold; margin-bottom: 8px;">
                🚨 Clipboard Hijack Detected!
            </div>
            <div style="margin-bottom: 8px;">
                Pasted content may have been modified by malware.
            </div>
            <div style="font-size: 12px; opacity: 0.9;">
                Content: "${contentPreview}"
            </div>
            <button onclick="this.parentElement.remove()" 
                    style="margin-top: 10px; background: white; color: #f44336; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer;">
                Dismiss
            </button>
        `;

        document.body.appendChild(warning);

        // Auto-remove after 10 seconds
        setTimeout(() => {
            if (warning.parentElement) {
                warning.remove();
            }
        }, 10000);

        // Flash the page border red briefly
        this.flashPageWarning();
    }

    showCopyFeedback() {
        // Show subtle green indicator for copy events
        const indicator = document.createElement('div');
        indicator.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #4CAF50;
            color: white;
            padding: 8px 12px;
            border-radius: 4px;
            z-index: 10000;
            font-family: Arial, sans-serif;
            font-size: 12px;
            opacity: 0.9;
        `;
        indicator.textContent = '📋 Copy protected';

        document.body.appendChild(indicator);

        // Remove after 2 seconds
        setTimeout(() => {
            if (indicator.parentElement) {
                indicator.remove();
            }
        }, 2000);
    }

    flashPageWarning() {
        const overlay = document.createElement('div');
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(244, 67, 54, 0.1);
            z-index: 9999;
            pointer-events: none;
            animation: pasteboardFlash 0.5s ease-out;
        `;

        // Add flash animation
        const style = document.createElement('style');
        style.textContent = `
            @keyframes pasteboardFlash {
                0% { opacity: 0; }
                50% { opacity: 1; }
                100% { opacity: 0; }
            }
        `;
        document.head.appendChild(style);

        document.body.appendChild(overlay);

        setTimeout(() => {
            overlay.remove();
            style.remove();
        }, 500);
    }

    async attemptClipboardClear() {
        try {
            // Try to clear clipboard (may not work due to security restrictions)
            if (navigator.clipboard && navigator.clipboard.writeText) {
                await navigator.clipboard.writeText('');
                console.log('Clipboard cleared as security measure');
            }
        } catch (error) {
            console.log('Unable to clear clipboard (security restriction):', error.message);
        }
    }

    async generateHash(content) {
        try {
            // Use SubtleCrypto for hashing
            const encoder = new TextEncoder();
            const data = encoder.encode(content);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);

            // Convert to hex string
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

            return hashHex;
        } catch (error) {
            console.error('Error generating hash:', error);
            // Fallback to simple hash
            return this.simpleHash(content);
        }
    }

    simpleHash(content) {
        // Fallback hash function
        let hash = 0;
        for (let i = 0; i < content.length; i++) {
            const char = content.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return hash.toString(16);
    }

    truncateContent(content, maxLength = 50) {
        if (content.length <= maxLength) {
            return content;
        }
        return content.substring(0, maxLength) + '...';
    }
}

// Initialize clipboard monitor when script loads
const clipboardMonitor = new ClipboardMonitor();

// Expose for debugging
window.clipboardMonitor = clipboardMonitor;
